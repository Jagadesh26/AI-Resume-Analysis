import { z } from 'zod';

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB Limit
const ACCEPTED_FILE_TYPES = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];

export const UploadSchema = z.object({
  resume: z
    .custom<File>((val) => val instanceof File, "Please upload a resume file")
    .refine((file) => file.size <= MAX_FILE_SIZE, `Max file size is 5MB.`)
    .refine(
      (file) => ACCEPTED_FILE_TYPES.includes(file.type),
      "Only .pdf and .docx formats are supported."
    ),
  provider: z.enum(['Gemini', 'Groq', 'OpenRouter', 'OpenAI', 'Claude'] as const),
  targetRole: z
    .string()
    .min(2, "Target role must be at least 2 characters")
    .max(100, "Target role is too long"),
});

export type UploadFormData = z.infer<typeof UploadSchema>;


// Base API Wrapper
export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
}

export interface JobSearchPayload {
  roles?: string[];
  skills?: string[];
  work_modes?: string[];
  location?: string;
}

// Job Recommendations Interface
export interface JobRecommendation {
  id?: string;
  title: string;
  company: string;
  location: string;
  experience: string;
  employmentType: string;
  workMode: string;
  salary: string;
  description: string;
  requiredSkills: string[];
  postedDate: string;
  applyUrl: string;
  source: string;
  matchScore: number;
  matchReason: string;
}

export interface JobSearchResponse {
  recommended_jobs: Array<{
    job_title?: string;
    title?: string;
    company?: string;
    location?: string;
    experience?: string;
    employment_type?: string;
    work_mode?: string;
    salary?: string;
    description?: string;
    skills?: string[];
    posted_date?: string;
    apply_url?: string;
    source?: string;
    match_score?: number;
    match_reason?: string;
  }>;
}

// Resume Analysis Interface
export interface ResumeAnalysisResponse {
  provider: string;
  model: string;
  atsScore: {
    score: number;
    grade: string;
    reason: string;
  };
  overallSummary: string;
  strengths: string[];
  weaknesses: string[];
  skills: {
    detected: string[];
    missing: string[];
  };
  sectionScores: {
    summary: number;
    experience: number;
    projects: number;
    skills: number;
    education: number;
  };
  keywords: {
    density: Record<string, number>;
  };
  analysis: {
    grammar: string[];
    formatting: string[];
  };
  suggestions: {
    rewrites: Array<{ before: string; after: string; reason: string }>;
    achievements: string[];
  };
  recommendations: string[];
  roleMatch: Array<{ role: string; percentage: number }>;
  recruiterFeedback: {
    interviewProbability: string;
    feedback: string;
  };
}