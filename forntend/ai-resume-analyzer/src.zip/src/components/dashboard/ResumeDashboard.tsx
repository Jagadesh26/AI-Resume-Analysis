import React from 'react';
import { motion } from 'framer-motion';
import { 
  CheckCircle2, 
  XCircle, 
  Target, 
  Award, 
  Briefcase, 
  PenTool, 
  AlertTriangle,
  Sparkles,
  UserCheck,
  Zap,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { ResumeAnalysisResponse } from '@/types';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 60 } },
};

const DashboardCard = ({ children, className, colSpan = 1 }: { children: React.ReactNode, className?: string, colSpan?: number }) => (
  <motion.div 
    variants={itemVariants}
    className={cn(
      "bg-slate-900/40 backdrop-blur-md border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col h-full",
      colSpan === 2 && "md:col-span-2 lg:col-span-2",
      colSpan === 3 && "md:col-span-2 lg:col-span-3",
      className
    )}
  >
    {children}
  </motion.div>
);

const ProgressBar = ({ label, percentage, colorClass }: { label: string, percentage: number, colorClass: string }) => (
  <div className="space-y-1.5 w-full">
    <div className="flex justify-between text-sm">
      <span className="text-slate-300 font-medium">{label}</span>
      <span className="text-slate-400">{percentage}%</span>
    </div>
    <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${percentage}%` }}
        transition={{ duration: 1, ease: "easeOut", delay: 0.5 }}
        className={cn("h-full rounded-full", colorClass)}
      />
    </div>
  </div>
);

interface ResumeDashboardProps {
  data: ResumeAnalysisResponse;
}

export const ResumeDashboard: React.FC<ResumeDashboardProps> = ({ data }) => {
  // Map strictly to the 'analysis' object from the backend
  const analysis = data?.analysis;
  if (!analysis) return null;

  const radius = 45;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (analysis.overall_score.score / 100) * circumference;

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="w-full max-w-7xl mx-auto space-y-6"
    >
      {/* Top Section: Score & Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* ATS Score Card */}
        <DashboardCard className="items-center justify-center text-center relative overflow-hidden group">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-32 bg-primary/10 blur-[60px] pointer-events-none" />
          <h2 className="text-lg font-semibold text-slate-200 mb-6 flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" /> ATS Match Score
          </h2>
          
          <div className="relative w-40 h-40 flex items-center justify-center mb-4">
            <svg className="transform -rotate-90 w-40 h-40">
              <circle cx="80" cy="80" r="45" className="stroke-slate-800" strokeWidth="8" fill="none" />
              <motion.circle 
                cx="80" cy="80" r="45" 
                className={cn(
                  "stroke-current",
                  analysis.overall_score.score >= 80 ? "text-emerald-500" : analysis.overall_score.score >= 60 ? "text-amber-500" : "text-rose-500"
                )}
                strokeWidth="8" fill="none"
                strokeLinecap="round"
                initial={{ strokeDasharray: circumference, strokeDashoffset: circumference }}
                animate={{ strokeDashoffset }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-4xl font-bold text-white">{analysis.overall_score.score}%</span>
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Grade {analysis.overall_score.grade}</span>
            </div>
          </div>
          <p className="text-sm text-slate-400 mt-2">{analysis.overall_score.reason}</p>
        </DashboardCard>

        {/* Overall Summary & Recruiter Feedback */}
        <DashboardCard colSpan={2} className="justify-between">
          <div>
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-accent" /> Executive Summary
            </h2>
            <p className="text-slate-300 leading-relaxed text-sm">
              {analysis.summary}
            </p>
          </div>
          
          <div className="mt-6 pt-6 border-t border-slate-800/50 flex flex-col sm:flex-row gap-6">
            <div className="flex-1 bg-primary/5 rounded-xl p-4 border border-primary/10">
              <div className="flex items-center gap-2 mb-2">
                <UserCheck className="w-4 h-4 text-primary" />
                <h3 className="text-sm font-semibold text-primary-foreground">Recruiter Feedback</h3>
              </div>
              <p className="text-sm text-slate-400">{analysis.recruiter_feedback.feedback}</p>
            </div>
            <div className="w-full sm:w-48 bg-slate-950/50 rounded-xl p-4 border border-slate-800 flex flex-col items-center justify-center text-center">
              <span className="text-xs text-slate-400 mb-1">Interview Probability</span>
              <span className="text-xl font-bold text-accent">{analysis.recruiter_feedback.interview_probability}</span>
            </div>
          </div>
        </DashboardCard>
      </div>

      {/* Middle Section: Strengths, Weaknesses, Section Scores */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <DashboardCard className="border-emerald-900/30">
          <h3 className="text-lg font-semibold text-emerald-400 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" /> Key Strengths
          </h3>
          <ul className="space-y-3">
            {analysis.strengths.map((strength, idx) => (
              <li key={idx} className="flex items-start gap-3 text-sm text-slate-300">
                <span className="mt-1 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                {strength}
              </li>
            ))}
          </ul>
        </DashboardCard>

        <DashboardCard className="border-rose-900/30">
          <h3 className="text-lg font-semibold text-rose-400 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" /> Critical Weaknesses
          </h3>
          <ul className="space-y-3">
            {analysis.weaknesses.map((weakness, idx) => (
              <li key={idx} className="flex items-start gap-3 text-sm text-slate-300">
                <span className="mt-1 w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0" />
                {weakness}
              </li>
            ))}
          </ul>
        </DashboardCard>

        <DashboardCard>
          <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-400" /> Section Scores
          </h3>
          <div className="space-y-4">
            <ProgressBar label="Experience" percentage={analysis.section_scores.experience.score} colorClass="bg-blue-500" />
            <ProgressBar label="Projects" percentage={analysis.section_scores.projects.score} colorClass="bg-cyan-500" />
            <ProgressBar label="Education" percentage={analysis.section_scores.education.score} colorClass="bg-indigo-500" />
            <ProgressBar label="Skills" percentage={analysis.section_scores.skills.score} colorClass="bg-purple-500" />
            <ProgressBar label="Summary" percentage={analysis.section_scores.summary.score} colorClass="bg-emerald-500" />
          </div>
        </DashboardCard>
      </div>

      {/* Skills & Role Match */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <DashboardCard colSpan={2}>
          <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" /> Skills Analysis
          </h3>
          <div className="space-y-6">
            <div>
              <h4 className="text-sm font-medium text-slate-400 mb-3">Detected Skills</h4>
              <div className="flex flex-wrap gap-2">
                {analysis.detected_skills.map((skill, idx) => (
                  <span key={idx} className="px-3 py-1 rounded-md bg-primary/10 border border-primary/20 text-primary-foreground text-xs font-medium">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-slate-400 mb-3">Missing Critical Skills</h4>
              <div className="flex flex-wrap gap-2">
                {analysis.missing_skills.map((skill, idx) => (
                  <span key={idx} className="px-3 py-1 rounded-md bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-medium">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </DashboardCard>

        <DashboardCard>
          <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-400" /> Role Match
          </h3>
          <div className="space-y-5">
            {analysis.role_match.map((role, idx) => (
              <ProgressBar 
                key={idx} 
                label={role.role} 
                percentage={role.match_percentage} 
                colorClass={idx === 0 ? "bg-accent" : "bg-slate-600"} 
              />
            ))}
          </div>
        </DashboardCard>
      </div>

      {/* Keywords, Grammar, & Formatting */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-cyan-400" /> Keyword Analysis
          </h3>
          <div className="mb-4">
             <ProgressBar label="Keyword Density" percentage={analysis.keyword_analysis.keyword_density} colorClass="bg-cyan-500" />
          </div>
          <div className="space-y-3 max-h-32 overflow-y-auto pr-2 custom-scrollbar">
            <h4 className="text-xs font-medium text-slate-400">Detected</h4>
            <div className="flex flex-wrap gap-1">
              {analysis.keyword_analysis.detected_keywords.map((word, idx) => (
                <span key={idx} className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-xs">{word}</span>
              ))}
            </div>
          </div>
        </DashboardCard>

        <DashboardCard>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-400" /> Grammar
          </h3>
          <div className="mb-4">
             <ProgressBar label="Grammar Score" percentage={analysis.grammar.score} colorClass="bg-emerald-500" />
          </div>
          {analysis.grammar.issues.length > 0 ? (
            <ul className="space-y-3">
              {analysis.grammar.issues.map((issue, idx) => (
                <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" /> {issue}
                </li>
              ))}
            </ul>
          ) : (
            <div className="flex items-center text-emerald-400 text-sm gap-2">
              <CheckCircle2 className="w-4 h-4" /> No major grammar issues detected.
            </div>
          )}
        </DashboardCard>

        <DashboardCard>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <PenTool className="w-5 h-5 text-purple-400" /> Formatting
          </h3>
           <div className="mb-4">
             <ProgressBar label="Formatting Score" percentage={analysis.formatting.score} colorClass="bg-purple-500" />
          </div>
          <ul className="space-y-3">
            {analysis.formatting.issues.map((issue, idx) => (
              <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 shrink-0 mt-1.5" /> {issue}
              </li>
            ))}
          </ul>
        </DashboardCard>
      </div>

      {/* Actionable Improvements: Rewrites & Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Bullet Point Rewrites */}
        <DashboardCard>
          <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" /> Bullet Point Rewrites
          </h3>
          <div className="space-y-6">
            {analysis.resume_rewrites.map((rewrite, idx) => (
              <div key={idx} className="bg-slate-950/50 rounded-xl p-4 border border-slate-800">
                <div className="mb-3">
                  <span className="text-xs font-semibold text-rose-400 uppercase tracking-wider mb-1 block">Before</span>
                  <p className="text-sm text-slate-400 line-through decoration-rose-900/50">{rewrite.before}</p>
                </div>
                <div>
                  <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-1 block">After</span>
                  <p className="text-sm text-slate-200">{rewrite.after}</p>
                </div>
              </div>
            ))}
          </div>
        </DashboardCard>

        {/* General Recommendations & Achievements */}
        <div className="space-y-6">
          <DashboardCard>
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" /> Achievement Suggestions
            </h3>
            <ul className="space-y-3">
              {analysis.achievement_suggestions.map((achievement, idx) => (
                <li key={idx} className="flex items-start gap-3 bg-slate-950/50 p-3 rounded-lg border border-slate-800/50">
                  <ArrowRight className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-300">{achievement}</span>
                </li>
              ))}
            </ul>
          </DashboardCard>

          <DashboardCard>
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-primary" /> Strategic Recommendations
            </h3>
            <ul className="space-y-3">
              {analysis.recommendations.map((rec, idx) => (
                <li key={idx} className="flex items-start gap-3 bg-slate-950/50 p-3 rounded-lg border border-slate-800/50">
                  <span className="w-6 h-6 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center shrink-0 mt-0.5 font-bold">
                    {idx + 1}
                  </span>
                  <span className="text-sm text-slate-300">{rec}</span>
                </li>
              ))}
            </ul>
          </DashboardCard>
        </div>

      </div>
    </motion.div>
  );
};