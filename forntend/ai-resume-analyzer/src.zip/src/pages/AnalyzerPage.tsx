import { } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { motion } from 'framer-motion';
import { UploadSchema } from '../types';
import type { UploadFormData } from '../types';
import { useAnalyzeResume } from '../hooks/useAnalyzeResume';
import { AILoadingState } from '../components/upload/AILoadingState';
// Assume Shadcn components are imported here: Card, Button, Input, Select, etc.

export const AnalyzerPage = () => {
  const analysis = result?.analysis;

  if (result && !analysis) {
      return (
          <div className="text-white">
              Invalid analysis response.
          </div>
      );
  }
  
  const { register, handleSubmit, setValue, formState: { errors } } = useForm<UploadFormData>({
    resolver: zodResolver(UploadSchema),
    defaultValues: { provider: 'Gemini' }
  });

  const onSubmit = (data: UploadFormData) => {
    analyze(data);
  };

  if (isPending) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <AILoadingState />
      </div>
    );
  }

  if (result) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="min-h-screen bg-slate-950 text-slate-50 p-8"
      >
        <div className="max-w-7xl mx-auto space-y-8">
          <header className="mb-12">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Analysis Complete
            </h1>
            <p className="text-slate-400 mt-2">Target Role: {result.roleMatch[0]?.role || 'Professional'}</p>
          </header>

          {/* Core Dashboard Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* ATS Score Card */}
            <div className="col-span-1 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-2xl">
              <h2 className="text-xl font-semibold mb-4 text-slate-200">ATS Match Score</h2>
              <div className="flex flex-col items-center justify-center h-48 relative">
                 {/* Insert Circular Progress Component Here */}
                 <span className="text-5xl font-bold text-cyan-400">{result.atsScore.score}%</span>
                 <span className="text-lg font-medium text-slate-400 mt-2">Grade: {result.atsScore.grade}</span>
              </div>
              <p className="text-sm text-slate-400 text-center">{result.atsScore.reason}</p>
            </div>

            {/* Strengths & Weaknesses */}
            <div className="col-span-2 grid grid-cols-2 gap-6">
               <div className="bg-slate-900/50 border border-emerald-900/50 rounded-xl p-6">
                 <h3 className="text-emerald-400 font-medium mb-3">Key Strengths</h3>
                 <ul className="space-y-2">
                   {result.strengths.map((s, i) => <li key={i} className="text-sm text-slate-300">• {s}</li>)}
                 </ul>
               </div>
               <div className="bg-slate-900/50 border border-rose-900/50 rounded-xl p-6">
                 <h3 className="text-rose-400 font-medium mb-3">Critical Weaknesses</h3>
                 <ul className="space-y-2">
                   {result.weaknesses.map((w, i) => <li key={i} className="text-sm text-slate-300">• {w}</li>)}
                 </ul>
               </div>
            </div>

            {/* Additional Modules mapped similarly according to UI spec */}
            {/* ... Skills, Grammar, Keywords, Recruiter Feedback ... */}

          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
      {/* Upload Glassmorphism Card */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl w-full bg-slate-900/40 backdrop-blur-xl border border-slate-800 p-8 rounded-2xl shadow-2xl"
      >
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Upload Resume</h2>
          <p className="text-slate-400">Supported formats: PDF, DOCX</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Drag & Drop Zone */}
          <div className="border-2 border-dashed border-slate-700 rounded-xl p-10 flex flex-col items-center justify-center hover:border-cyan-500/50 transition-colors bg-slate-950/50 cursor-pointer relative">
            <input 
              type="file" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              onChange={(e) => {
                if(e.target.files?.[0]) setValue('resume', e.target.files[0]);
              }}
            />
            <p className="text-slate-300 font-medium">Drag & drop your file here</p>
            <p className="text-slate-500 text-sm mt-2">or click to browse</p>
          </div>
          {errors.resume && <span className="text-rose-500 text-sm">{errors.resume.message}</span>}

          {/* Form Controls */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">Target Role</label>
              <input 
                {...register('targetRole')} 
                placeholder="e.g., Python Backend Developer"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
              />
              {errors.targetRole && <span className="text-rose-500 text-sm">{errors.targetRole.message}</span>}
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300">AI Provider</label>
              <select 
                {...register('provider')}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-white focus:ring-2 focus:ring-cyan-500 outline-none transition-all"
              >
                <option value="Gemini">Google Gemini</option>
                <option value="OpenAI">OpenAI GPT-4</option>
                <option value="Claude">Anthropic Claude</option>
                <option value="Groq">Groq Llama-3</option>
              </select>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)] hover:shadow-[0_0_30px_rgba(6,182,212,0.5)]"
          >
            Analyze Resume
          </button>
        </form>
      </motion.div>
    </div>
  );
};